# Arix Themes Releases V1.3
Un Official Arix Themes Updated By Gyu


**Hanya Ada 1 Pemilik Di Indonesia Tema Ini Yaitu Saya Sendiri**

[Pricelist Harga Tema](https://github.com/withfabian/arix-themes/blob/main/pricelist.md)

[Change Language](https://github.com/withfabian/arix-themes/blob/main/english.md)

[Preview Themes](https://github.com/withfabian/arix-themes/blob/main/preview.md)

Arix Themes Version 1.3 New Beta

---

## Changelogs
  - Membuat Bahasa Khusus ( Bahasa Indonesia )
  - Support Php Version 8.2
  - Update React Icon Rilis Terbaru
  - Support Pterodactyl Versi 1.11.10 Versi Terbaru 2025
  - Perbaiki Error Dan Lainnya

---

## Cara Installasi Tema

  - Kalian Wajib Menjalankan Command ini Terlebih Dahulu
    ```
    curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
    ```
    ```
    sudo apt install -y nodejs
    ```
    ```
    npm i -g yarn
    ```
    ```
    cd /var/www/pterodactyl
    ```
    ```
    yarn
    ```
---
  - Setelah itu Kalian Wajib Install nvm Versi 16
    ```
    curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.1/install.sh | bash
    ```
    ```
    source ~/.bashrc
    ```
    ```
    nvm install 16
    ```
    ```
    nvm use 16
    ```
  - Lalu Langkah Terakhir Kalian Jalankan Command
    ```
    php artisan arix install
    ```
  - setelah Itu Kalian Buka Folder /var/www/pterodactyl/app/Http/ViewComposers/ Dan Di File AssetComposer.php Kalian Edit Semau Kalian

---

## WARNING DILARANG DIPERJUAL BELIKAN KEMBALI
JIKA KETAHUAN MAKA KALIAN TIDAK AKAN DAPAT FREE UPDATE KEMBALI KARENA SETIAP BULANYA AKAN GANTI GANTI VERSI PTERODACTYL DAN TEMA INI JUGA AKAN BERUBAH UBAH SETIAP BULANNYA UNTUK VERSINYA



Jika Ingin Membeli Open Tiket Di Discord https://discord.gg/eRBFCQSqsv



---
